package bg.sofia.uni.fmi.jira;

public class Component {
    public Component(String name, String shortName, User creator){

    }
}
