package bg.sofia.uni.fmi.jira;

import bg.sofia.uni.fmi.jira.interfaces.Issue;
import bg.sofia.uni.fmi.jira.interfaces.IssueTracker;

import java.time.LocalDateTime;

public class Jira implements IssueTracker {

    Issue[] issues;

    public Jira(Issue[] issue){

    }
    public Issue[] findAll(Component component, IssueStatus status){

    }

    public Issue[] findAll(Component component, IssuePriority priority){

    }

    public Issue[] findAll(Component component, IssueType type){

    }

    public Issue[] findAll(Component component, IssueResolution resolution){

    }

    public Issue[] findAllIssuesCreatedBetween(LocalDateTime startTime, LocalDateTime endTime){

    }

    public Issue[] findAllBefore(LocalDateTime dueTime){

    }

}
