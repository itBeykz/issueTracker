package bg.sofia.uni.fmi.jira;

public class User {
    public User(String userName){

    }
}
