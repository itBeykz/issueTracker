package bg.sofia.uni.fmi.jira.interfaces;

import bg.sofia.uni.fmi.jira.Component;
import bg.sofia.uni.fmi.jira.User;

import java.awt.*;

public class Issue {
    public Issue(IssuePriority priority,
                 Component component, User reporter,
                 String description)
            throws InvalidReporterException;
}
