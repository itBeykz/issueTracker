package bg.sofia.uni.fmi.jira.interfaces;

import bg.sofia.uni.fmi.jira.Component;

import java.time.LocalDateTime;

public interface IssueTracker {

        public Issue[] findAll(bg.sofia.uni.fmi.jira.Component component, IssueStatus status);

        public Issue[] findAll(bg.sofia.uni.fmi.jira.Component component, IssuePriority priority);

        public Issue[] findAll(bg.sofia.uni.fmi.jira.Component component, IssueType type);

        public Issue[] findAll(Component component, IssueResolution resolution);

        public Issue[] findAllIssuesCreatedBetween(LocalDateTime startTime, LocalDateTime endTime);

        public Issue[] findAllBefore(LocalDateTime dueTime);

}
